-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Mar 09, 2017 at 11:47 PM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `translator`
--
CREATE DATABASE IF NOT EXISTS `translator` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `translator`;

-- --------------------------------------------------------

--
-- Table structure for table `UK_US`
--

CREATE TABLE `UK_US` (
  `id` bigint(20) unsigned NOT NULL,
  `UK_id` int(11) DEFAULT NULL,
  `US_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `UK_US`
--

INSERT INTO `UK_US` (`id`, `UK_id`, `US_id`) VALUES
(80, 81, 46),
(82, 82, 47),
(84, 83, 48),
(86, 84, 49),
(88, 85, 50),
(90, 86, 51),
(92, 87, 52),
(94, 88, 53),
(96, 89, 54),
(98, 90, 55),
(100, 94, 56),
(101, 95, 57),
(102, 96, 58),
(103, 97, 59),
(104, 98, 60),
(105, 99, 61),
(106, 100, 62),
(107, 101, 63),
(108, 102, 64),
(109, 103, 65),
(110, 104, 66),
(111, 105, 67),
(112, 106, 68),
(113, 107, 69),
(114, 108, 70),
(115, 110, 72),
(116, 111, 73),
(117, 112, 74),
(118, 113, 75),
(119, 114, 76),
(120, 115, 77);

-- --------------------------------------------------------

--
-- Table structure for table `uk_words`
--

CREATE TABLE `uk_words` (
  `id` bigint(20) unsigned NOT NULL,
  `definition` text,
  `example` text,
  `region` varchar(255) DEFAULT NULL,
  `word` varchar(255) NOT NULL,
  `country` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uk_words`
--

INSERT INTO `uk_words` (`id`, `definition`, `example`, `region`, `word`, `country`) VALUES
(80, 'scratch, scrape or graze the skin.', 'I scraged my elbow', 'Midlands', 'Scrage', 'UK'),
(81, 'a person who is daft, mad or losing the plot.', 'He is yampy that one.', 'Midlands', 'Yampy', 'UK'),
(82, 'playing, wasting time ', 'Stop charting around!', 'Midlands', 'charting about', 'UK'),
(83, 'cry loudly, such as the noisy wailing and sobbing of an upset child.', 'She was bawling her head off. ', 'Midlands', 'bawl', 'UK'),
(84, 'outdated', 'His shirt is right noggy. ', 'Midlands', 'noggy', 'UK'),
(85, 'to hit someone', 'I will lamp you if you carry on!', 'Midlands', 'lamp', 'UK'),
(86, 'a snack or going to get food ', 'I am off to get my snap ', 'Midlands', 'snap', 'UK'),
(87, 'fumbling ', 'He is so craggy handed I do not  trust him with good dishes. ', 'Midlands', 'craggy handed ', 'UK'),
(88, 'stupid or slow witted ', 'That guy is half soaked!', 'Midlands', 'half soaked ', 'UK'),
(89, 'a sulking expression ', 'Put yer fizzog straight.', 'Midlands', 'fizzog ', 'UK'),
(90, 'coins and bills ', 'I am swimming in ackers ', 'Midlands', 'Ackers ', 'UK'),
(95, 'Braggadocio', 'â€œDonâ€™t listen to him. Heâ€™s all mouth and no trousers.â€', 'National', 'All mouth and no trousers ', 'UK'),
(96, 'portable light source ', 'Give me a torch, its dark in here. ', 'National', 'torch ', 'UK'),
(97, 'a moving platform or cage for carrying passengers or freight from one level to another, as in a building.', 'Hold the lift please ', 'National', 'lift ', 'UK'),
(98, 'walk leisurely ', 'I went for a dander', 'Northern Ireland', 'dander ', 'UK'),
(99, 'embarassed for someone else ', 'I was scundered for you when you were singing ', 'Northern Ireland', 'Scundered  ', 'UK'),
(100, 'go out drinking', 'My friends and I were swalling last night.', 'Northern Ireland', 'swalling ', 'UK'),
(101, 'the opposite of do ', 'Dinnae gie me a gammy then, ah didnae want wan anyhow', 'Scotland', 'Dinnae', 'UK'),
(102, 'a slow person, one who is not very smart ', 'What an dobber!', 'Scotland', 'dobber ', 'UK'),
(103, 'a phrase used when someone is upset or excited ', 'Keep the hiede, no need to yell!', 'Scotland', 'keep the hieid', 'UK'),
(104, 'sweets ', 'oreos are my favorite biscuits', 'National', 'biscuit ', 'UK'),
(105, 'a rented place to live ', 'My flat is on the 3rd floor ', 'National', 'flat ', 'UK'),
(106, 'a device to protect from the rain ', 'I forgot my bumbershoot, I am soaked!', 'National', 'bumbershoot ', 'UK'),
(107, 'minced pork, beef, or other meats, often combined, together with various added ingredients and seasonings, usually stuffed into a prepared intestine or other casing and often made in links.', 'I had bangers for breakfast', 'National', 'banger ', 'UK'),
(108, 'a mild curse word ', 'That damn car!', 'National', 'bloody ', 'UK'),
(109, 'something from another era ', 'that shirt is right antwacky', 'Yorkshire', 'Antwacky', 'UK'),
(110, 'short for television ', 'I saw something good on the telly ', 'National', 'telly', 'UK'),
(111, 'go out of town for fun ', 'My summer holiday was great!', 'National', 'holiday ', 'UK'),
(112, 'car hood ', 'open the bonnet ', 'National', 'bonnet ', 'UK'),
(113, 'the storage compartment in the back of a car ', 'The boot is loaded and ready', 'National', 'boot ', 'UK'),
(114, 'bed for a baby', 'Put the baby down in her cot', 'National', 'cot', 'UK'),
(115, 'yellow or green long tender summer squash', 'They use courgette for their pasta', 'National', 'courgette', 'UK');

-- --------------------------------------------------------

--
-- Table structure for table `us_words`
--

CREATE TABLE `us_words` (
  `id` bigint(20) unsigned NOT NULL,
  `definition` text,
  `example` text,
  `region` varchar(255) DEFAULT NULL,
  `word` varchar(255) NOT NULL,
  `country` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `us_words`
--

INSERT INTO `us_words` (`id`, `definition`, `example`, `region`, `word`, `country`) VALUES
(45, 'scratch, scrape or graze the skin.', 'I scraped my elbow!', 'National', 'Scrape', 'US'),
(46, 'a person who is daft, mad or losing the plot.', 'He is one Crazy guy!', 'National', 'Crazy', 'US'),
(47, 'playing, wasting time ', 'Stop messing around and get to work.', 'National', 'messing around', 'US'),
(48, 'cry loudly, such as the noisy wailing and sobbing of an upset child.', 'She was crying like a baby.', 'National', 'cry', 'US'),
(49, 'outdated', 'his clothing is so old fashioned.', 'National', 'old fashioned ', 'US'),
(50, 'to hit someone', 'If you dont stop yelling at me I will beat you up!', 'National', 'beat up ', 'US'),
(51, 'a snack or going to get food ', 'I am going to get a meal. ', 'National', 'meal', 'US'),
(52, 'fumbling ', 'I tripped over my own two feet, I am so clumsy.', 'National', 'clumsy ', 'US'),
(53, 'stupid or slow witted ', 'He is so slow, he rides the short bus.', 'National', 'slow ', 'US'),
(54, 'a sulking expression ', 'You have such a sourpuss. ', 'National', 'sourpuss ', 'US'),
(55, 'coins and bills ', 'I have a pocket full of money', 'National', 'money', 'US'),
(56, 'asdas', 'asd', 'Northeast', 'aszda', 'US'),
(57, 'Braggadocio', 'â€œDonâ€™t listen to him. Heâ€™s all talk and no action.â€', 'National', 'All talk, no action', 'US'),
(58, 'portable light source ', 'Give me a flashlight, its dark in here. ', 'National', 'flashlight ', 'US'),
(59, 'a moving platform or cage for carrying passengers or freight from one level to another, as in a building.', 'Hold the elevator please ', 'National', 'elevator ', 'US'),
(60, 'walk leisurely ', 'I went for a nice stroll ', 'National', 'stroll ', 'US'),
(61, 'embarassed for someone else ', 'I was mortified for you when you were singing ', 'National', 'Mortified for you', 'US'),
(62, 'go out drinking', 'I went drinking with my friends last night. ', 'National', 'drinking ', 'US'),
(63, 'the opposite of do ', 'I dont know. ', 'National', 'do not ', 'US'),
(64, 'a slow person, one who is not very smart ', 'What an idiot!', 'National', 'idiot ', 'US'),
(65, 'a phrase used when someone is upset or excited ', 'calm down, stop yelling!', 'National', 'calm down ', 'US'),
(66, 'sweets ', 'I love oreos they are my favorite cookie', 'National', 'cookie ', 'US'),
(67, 'a rented place to live ', 'My apartment is a fifth floor walk up ', 'National', 'apartment ', 'US'),
(68, 'a device to protect from the rain ', 'I forgot my umbrella, I am soaked!', 'National', 'umbrella ', 'US'),
(69, 'minced pork, beef, or other meats, often combined, together with various added ingredients and seasonings, usually stuffed into a prepared intestine or other casing and often made in links.', 'I had eggs and sausage for breakfast ', 'National', 'sausage ', 'US'),
(70, 'a mild curse word ', 'That damn car ', 'National', 'damn', 'US'),
(72, 'short for television ', 'I watched a great TV program last night ', 'National', 'TV', 'US'),
(73, 'go out of town for fun ', 'I had the best vacation this summer ', 'National', 'vacation ', 'US'),
(74, 'car hood ', 'Look under the hood ', 'National', 'hood ', 'US'),
(75, 'the storage compartment in the back of a car ', 'I loaded the luggage in the trunk. ', 'National', 'trunk ', 'US'),
(76, 'bed for a baby', 'Put the baby down in her crib', 'National', 'crib', 'US'),
(77, 'yellow or green long tender summer squash', 'He put zucchini in his salad', 'National', 'zucchini', 'US');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `UK_US`
--
ALTER TABLE `UK_US`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `uk_words`
--
ALTER TABLE `uk_words`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `word` (`word`);

--
-- Indexes for table `us_words`
--
ALTER TABLE `us_words`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `word` (`word`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `UK_US`
--
ALTER TABLE `UK_US`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=121;
--
-- AUTO_INCREMENT for table `uk_words`
--
ALTER TABLE `uk_words`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=116;
--
-- AUTO_INCREMENT for table `us_words`
--
ALTER TABLE `us_words`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=78;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
